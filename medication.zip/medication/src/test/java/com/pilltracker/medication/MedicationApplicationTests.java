package com.pilltracker.medication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
